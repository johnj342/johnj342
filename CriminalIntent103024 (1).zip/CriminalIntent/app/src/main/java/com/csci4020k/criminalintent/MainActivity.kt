package com.csci4020k.criminalintent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.csci4020k.criminalintent.databinding.FragmentCrimeDetailBinding

class MainActivity: AppCompatActivity() {
    private lateinit var binding: FragmentCrimeDetailBinding

    override fun onCreate(savedInstanceState: Bundle?){
        //super.onCreate(savedInstanceState)
        //binding = FragmentCrimeDetailBinding.inflate(layoutInflater)
        //setContentView(binding.root)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
}