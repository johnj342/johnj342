package com.csci4020k.criminalintent

import androidx.fragment.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.util.Log
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.csci4020k.criminalintent.databinding.FragmentCrimeListBinding
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

private const val TAG = "CrimeListFragment"
class CrimeListFragment: Fragment() {
    private var fragmentBinding: FragmentCrimeListBinding? = null
    private val binding get() = checkNotNull(fragmentBinding){
        "Cannot access binding because it is null. Is it visible"
    }
    private val crimeListViewModel: CrimeListViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        fragmentBinding = FragmentCrimeListBinding.inflate(
            inflater, container, false)
        binding.crimeRecyclerView.layoutManager = LinearLayoutManager(context)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?){
        super.onViewCreated(view, savedInstanceState)
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED){
                crimeListViewModel.crimes.collect{
                    crimes ->
                    binding.crimeRecyclerView.adapter = CrimeListAdapter(crimes){
                        crimeId -> findNavController().navigate(
                        CrimeListFragmentDirections.showCrimeDetail(crimeId))
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        fragmentBinding = null
    }
}







