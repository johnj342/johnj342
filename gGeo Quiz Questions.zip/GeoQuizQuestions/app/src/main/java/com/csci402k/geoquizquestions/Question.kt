package com.csci402k.geoquizquestions.com.csci402k.geoquizquestions

data class Question(
    @StringsRes val textResID: Int,
            val answer: Boolean)

annotation class StringsRes
