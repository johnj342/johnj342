package com.csci4020k.geoquizquestions
import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.csci402k.geoquizquestions.com.csci402k.geoquizquestions.Question
import com.csci402k.geoquizquestions.databinding.ActivityMainBinding
import kotlin.math.roundToInt

private const val TAG = "MainActivity"
class MainActivity : AppCompatActivity(){
    private lateinit var binding: ActivityMainBinding
 private var currentIndex = 0 //keep track of the question index
    private var countercorrectAnswer = 0 // keep track of how many correct answers
    //generate the questions
    private val questionBank = listOf(
        Question(R.string.question_australia, true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, false),
        Question(R.string.question_africa, false),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //create the listener for all buttons
        //true button
        binding.trueButton.setOnClickListener {
            Toast.makeText(
                this,
                R.string.correct_toast,
                Toast.LENGTH_SHORT
            ).show()
            //method-called to check answer
            checkAnswer(true)

        }
        //false button

        binding.falseButton.setOnClickListener {
            Toast.makeText(
                this,
                R.string.correct_toast,
                Toast.LENGTH_SHORT
            ).show()
            //method-called to check answer
            checkAnswer(false)
        }
        //next button
        binding.nextButton.setOnClickListener {
        currentIndex = (currentIndex + 1) % questionBank.size
        //method-called to update question
        updateQuestion()
    }
        //method to update question
        private fun updateQuestion() {
            val questionTextResId = questionBank[currentIndex].textResID
             //create binding to display question
            binding.questionTextView.setText(questionTextResId)
        }
    binding.backButton.setOnClickListener {
    currentIndex = if(currentIndex == 0) {
        5
    } else {
        (currentIndex - 1) % questionBank.size
    }
    //method-called to update question
    updateQuestion()
    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer = questionBank[currentIndex].answer
        var messageResId = ""
        if(userAnswer == correctAnswer){
            messageResId = "Correct!"
            countercorrectAnswer = (countercorrectAnswer + 1)
        }
        else{
            messageResId = "Incorrect!"
        }
        Toast.makeText(this,messageResId, Toast.LENGTH_SHORT).show()

        if(currentIndex == questionBank.size -1){
            binding.nextButton.isEnabled = false
            binding.backButton.isEnabled = false
            binding.trueButton.isEnabled = false
            binding.falseButton.isEnabled = false

            printPercentages()
        }
    }
        //printPrecentage method
        private fun printPercentages(){
            val percentage = (countercorrectAnswer.toDouble()/ questionBank.size.toDouble()) * 100.0
            val messageToDisplay =if(percentage > 70){
                "${percentage.roundToInt()} % Congratulations!"
            }else {
                "${percentage.roundToInt()} % Try Harder Next Time!"
            }
            Toast.makeText(this,
                messageToDisplay, Toast.LENGTH_LONG).show()

        }        }
    //debugging purposes
    override fun onStart(){
        super.onStart()
        Log.d(TAG, "onStart() called.")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume() called.")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause() called.")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy() called.") }}

    private fun checkAnswer(b: Boolean) {

    }
}

